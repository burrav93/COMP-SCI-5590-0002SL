function [score_train,score_test]=LDA_1(train_data,test_data,v)
% Compute the mean of the data matrix
m=mean(train_data,2); %for the training set

% Calculating Mean of Each Class%%
j=1;
for i=0:5:195
    mea(:,j)=mean(train_data(:,i+1:i+5),2);
    m_class(:,i+1:i+5)=repmat(mea(:,j),[1,5]);    %% Calculating Mean of Each Class%%
    j=j+1;
end;

% Calculate the within class scatter (SW)
     temp=zeros(10304,10304);
     wsca=zeros(10304,10304);
 for i =0:5:195
     temp=(train_data(:,i+1:i+5)-m_class(:,i+1:i+5))*((train_data(:,i+1:i+5)-m_class(:,i+1:i+5))');
     wsca=temp+wsca;                %%calculating with in scatter matrix%% 
 end;
 
% v=pinv(wsca); % Calculate the within class scatter (SW)
 
  %%Calculating between scatter matrix%%
  temp1=zeros(10304,10304);
  bsca=zeros(10304,10304);
 for i=1:40
     temp1=(temp(:,i)-m)*((temp(:,i)-m)');
     bsca=temp1+bsca;            %%Calculating between scatter matrix%%
 
  end;

% Subtract the mean from each image [Centering the data]
d=train_data-repmat(m,1,200); %for the training set

test_data=test_data-repmat(mean(test_data,2),1,200);% performing the mean of the test matrix and subtracting the mean from each image(centering the data)

% find eigen values and eigen vectors of the (v)
[evec,eval]=eig(v*bsca);

% Sort the eigen vectors according to the eigen values
eigvalue = diag(eval);
[junk, index] = sort(eigvalue,'descend');

% Compute the number of eigen values that greater than zero (you can select any threshold)
count1=0;
for i=1:size(eigvalue,1)
    if(eigvalue(i)>0)
        count1=count1+1;
    end
end

% And also we can use the eigen vectors that the corresponding eigen values is greater than zero(Threshold) and this method will decrease the
% computation time and complixity 
vec=evec(:,index(1:40)); %Number of principal components used

%projection
tr_pro=vec'*d; %train projection
ts_pro=vec'*test_data; %test projection
tr_pro=abs(tr_pro);
ts_pro=abs(ts_pro);
%Use Euclidean distance as distance metrics.
D=pdist2(tr_pro',tr_pro','Euclidean');

norm=max(D(:));
normmat=1/norm*(D);
euc=pdist2(ts_pro',ts_pro');
%euc=squareform(euc);
m=max(euc(:));
euc=1/m*euc;
normmat=normmat';
j=1;
for i=0:5:195
score_train(:,j)=mean(normmat(:,i+1:i+5),2); %%to find the scores of LDA at each level
j=j+1;
end;
euc=euc';
j=1;
for i=0:5:195
score_test(:,j)=mean(euc(:,i+1:i+5),2);
j=j+1;
end;
end






