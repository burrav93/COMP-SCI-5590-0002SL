%data extraction using imageset
load('eigvector.mat');
load('eigvl.mat');
load('v.mat');
load('wsca.mat');
Data = imageSet('faces_att','recursive');
train_data=cell(1,200);
test_data=cell(1,200);
a = 1;
 for j=1:40     
     for i=1:5     %first five images of all 40 subjects for training
         X= read(Data(j),i);
         X=reshape(X,prod(size(X)),1);
         X=double(X);
         train_data{a} = X;
         a = a + 1;
     end;
 end;
 a=1;
  for j=1:40       %40 subjects
     for i=6:10    %last five images (6 to 10) of all 40 subjects for testing
         X= read(Data(j),i);
         X=reshape(X,prod(size(X)),1);
         X=double(X);
         test_data{a} = X;
         a = a + 1;
     end;
 end;
 
%%converting the cellarray to ordinary array or matrix
train_data=cell2mat(train_data); 
test_data=cell2mat(test_data);

%PCA and LDA scores
[pca_score_train,pca_score_test]=PCA_1(train_data,test_data,eigvl,eigvector);
[lda_score_train,lda_score_test]=LDA_1(train_data,test_data,v);

%Scores sum of both PCA and LDA
sum_score=lda_score_train+pca_score_train;
test_sum_score=lda_score_test+pca_score_test;

%performance evaluation plotting
temp=[zeros(1,5),ones(1,195)]';
for i=1:40
        target(:,i)=temp(:,:);
       temp=circshift(temp,5);    %% creating Target value%%
end;

%sum_score=(sum_score-min(sum_score))/((max(sum_score)-min(sum_score)));
%ezroc3(sum_score,target,2,'sum rule',1); %Sum rule (Average rule)

temp1=[zeros(1,5),ones(1,195)]';
for i=1:40
        target1(:,i)=temp1(:,:);
       temp1=circshift(temp1,5);    %% creating Target value%%
end;
%train_sum_score=(train_sum_score-min(train_sum_score))/((max(train_sum_score)-min(train_sum_score)));
%ezroc3(train_sum_score,target1,2,' train sum rule',1);

for i=1:200
     for j=1:40
         tempmat=[lda_score_test(i,j),pca_score_test(i,j)];
         max_score(i,j)=max(tempmat);%Max score rule
     end; 
 end;
 for i=1:200
     for j=1:40
         tempmat=[lda_score_test(i,j),pca_score_test(i,j)];
         min_score(i,j)=min(tempmat);%Min score rule
     end;
 end;
%ezroc3(max_score,target,2,'max rule',1); 
%ezroc3(min_score,target,2,'min rule',1); 

roc_max=ezroc3(max_score,target,2,'max rule',1);
roc_min=ezroc3(min_score,target,2,'min rule',1);
roc_average=ezroc3(test_sum_score,target,2,'average rule',1);
roc_LDA=ezroc3(pca_score_test,target,2,'LDA',1);
roc_PCA=ezroc3(lda_score_test,target,2,'PCA',1);

%figure(22), plot(roc_max(2,:),roc_max(1,:),'LineWidth',3),axis([-0.002 1 0 1.002]);
%hold on
 %plot(roc_min(2,:),roc_min(1,:),'LineWidth',3),axis([-0.002 1 0 1.002]); hold on;
 
 plot(roc_average(2,:),roc_average(1,:),'LineWidth',3),axis([-0.002 1 0 1.002]); hold on;
 
 plot(roc_PCA(2,:),roc_PCA(1,:),'LineWidth',3),axis([-0.002 1 0 1.002]); hold on;
 
 plot(roc_LDA(2,:),roc_LDA(1,:),'LineWidth',3),axis([-0.002 1 0 1.002]); hold on;

 legend('average rule','pca','lda');
