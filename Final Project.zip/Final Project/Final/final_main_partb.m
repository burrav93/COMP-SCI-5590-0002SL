%data extraction using imageset
load('eigvector.mat');
load('eigvl.mat');
load('v.mat');
load('wsca.mat');
Data = imageSet('faces_att','recursive');
train_data=cell(1,200);
test_data=cell(1,200);
a = 1;
 for j=1:40     
     for i=1:5     %first five images of all 40 subjects for training
         X= read(Data(j),i);
         X=reshape(X,prod(size(X)),1);
         X=double(X);
         train_data{a} = X;
         a = a + 1;
     end;
 end;
 a=1;
  for j=1:40       %40 subjects
     for i=6:10    %last five images (6 to 10) of all 40 subjects for testing
         X= read(Data(j),i);
         X=reshape(X,prod(size(X)),1);
         X=double(X);
         test_data{a} = X;
         a = a + 1;
     end;
 end;
 
%%converting the cellarray to ordinary array or matrix
train_data=cell2mat(train_data); 
test_data=cell2mat(test_data);

%PCA and LDA scores
[pca_score_train,pca_score_test]=PCA_1(train_data,test_data,eigvl,eigvector);
[lda_score_train,lda_score_test]=LDA_1(train_data,test_data,v);

%performance evaluation plotting
temp=[zeros(1,5),ones(1,195)]';
for i=1:40
        target(:,i)=temp(:,:);
       temp=circshift(temp,5);    %% creating Target value%%
end;

%sum_score=(sum_score-min(sum_score))/((max(sum_score)-min(sum_score)));
%ezroc3(sum_score,target,2,'sum rule',1); %Sum rule (Average rule)

temp1=[zeros(1,5),ones(1,195)]';
for i=1:40
        target1(:,i)=temp1(:,:);
       temp1=circshift(temp1,5);    %% creating Target value%%
end;
 %labels 
labels=zeros(200,200);
for i=1:200
    for j=1:200
        if(fix((i-1)/5)==fix((j-1)/5))
            labels(i,j)=0;
        else
            labels(i,j)=1;
        end
    end
end

% ROC without Multi-instance

roc_LDA=ezroc3(euc,labels,2,'LDA',1);
roc_PCA=ezroc3(euc,labels,2,'PCA',1);

% ROC with Multi-instance
roc_M_LDA=ezroc3(lda_score_test,target1,2,'LDA_M',1);
roc_M_PCA=ezroc3(pca_score_test,target1,2,'PCA_M',1);


figure(),
hold on
 plot(roc_M_LDA(2,:),roc_M_LDA(1,:),'LineWidth',3),axis([-0.002 1 0 1.002]); hold on;
 
 plot(roc_M_PCA(2,:),roc_M_PCA(1,:),'LineWidth',3),axis([-0.002 1 0 1.002]); hold on;
 
 plot(roc_PCA(2,:),roc_PCA(1,:),'LineWidth',3),axis([-0.002 1 0 1.002]); hold on;
 
 plot(roc_LDA(2,:),roc_LDA(1,:),'LineWidth',3),axis([-0.002 1 0 1.002]); hold on;
 
 legend('LDA with Multi-instance','PCA with Multi-instance','PCA without Multi-instance','LDA without Multi-instance');
